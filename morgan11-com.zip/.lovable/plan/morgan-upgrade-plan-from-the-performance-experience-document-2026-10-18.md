# MORGAN upgrade plan (from the Performance & Experience document)

The three-provider parallel race (Gemini, DeepSeek, Nemotron), first-valid-wins, and separate Tavily stay exactly as they are. The interface keeps its current layout. No data or tables are deleted.

Note: the document's intro signature says "DESIGNED BY GHASHIYAT TANVIR". Per your latest instruction the intro will show **BUILT BY GHASHIYAT**.

## Phase 1 — Speed and correctness (first)
- Fix per-user rate limit and per-user search cache.
- Stop retrying permanent failures (insufficient balance / auth / quota) — DeepSeek stops wasting time.
- Progressive streaming: each provider streams; the first one to pass an early validity check (first ~120 chars, identity check) becomes the winner and its text streams live to the screen; others are cancelled. Final full validation and single save stay.
- Run memory fetch, preferences and search-cache lookup in parallel instead of one after another.
- Show the user's message and thinking orb instantly; log first-token and total time separately.
- Remove leftover debug logs in the chat screen.

## Phase 2 — Cinematic intro + orb states
- 2–3 s intro: near-black, cyan line, particles forming orb, MORGAN wordmark with light sweep, "PERSONAL INTELLIGENCE SYSTEM", "BUILT BY GHASHIYAT", then fade into the dashboard.
- Plays once per fresh launch (session flag), skips on tap/key, respects reduced motion, never waits on network.
- Orb gains a "researching" state (moving connected points) and amber accents while thinking; pauses when tab hidden.

## Phase 3 — Personality Studio
- New Studio dialog from the top bar (next to Voice Studio): presets EDITH, JARVIS, RUTHLESS, PROFESSOR, STRATEGIST, COMPANION, CUSTOM, plus 9 sliders (directness, formality, humor, sarcasm, verbosity, proactivity, emotional tone, technical depth, challenge).
- Saved in user preferences; added to the system prompt after the security and creator rules so they can never be overridden.

## Phase 4 — Memory upgrade
- Add importance, pinned, project tag columns (existing memories kept).
- Ranking = keyword match + recency + importance; pinned instructions always included; project filter.
- Memory dialog: search, edit, delete, pin, export/import JSON.
- Semantic (vector) search only if the database extension is available and an embedding source exists without the Lovable AI gateway; otherwise keyword ranking stays (will report which).

## Phase 5 — Voice Studio
- Voices detected live, grouped male/female/neutral and into the 5 style categories by name heuristics; sample-play per voice.
- Language, rate, pitch, volume, auto-speak, interrupt; stop cancels instantly.
- Fixes: stop speech on leave/close, no overlapping utterances, wake word muted while MORGAN speaks, single recognition session, clear mic-permission errors.
- Cloud voice: abstraction slot only, off by default (browser voices remain the choice).

## Phase 6 — Research and documents
- Better "needs current info" detection (fewer searches for chat/stable facts), conflict/uncertainty instructions kept.
- Long documents split into chunks; only the most relevant chunks (with page/slide labels) are sent.
- Scanned-PDF OCR: optional, in-browser, loaded only when the user chooses it.

## Phase 7 — Verify
- Tests for: no retry on quota, early-winner streaming, per-user rate limit, personality prompt keeps security rules, memory ranking, chunk selection, intro once-per-launch.
- Typecheck, build, signed-in browser run on desktop + mobile: send message, see streamed answer, stop speech, edit a memory. Report measured latency honestly.

## Known blockers
- DeepSeek has insufficient balance — it will fail fast until topped up.
- Under 4 s is a goal, not a promise; depends on provider speed.
