# Make MORGAN's answers make sense

## What I found (from your real chats and reply logs, last 7 days)

- **The weak AI wins almost every reply.** The small OpenRouter model (Mistral Small 24B) won 68 of 74 races because it starts typing first. Gemini, the smarter one, won only 5. Most "senseless" or generic replies come from that.
- **Full-form misfire.** "What are you" answered "MORGAN means Moments Offered Readily…". The rule currently also fires for "what is MORGAN / tell me about yourself".
- **Robotic small talk.** "Fine yours" → "I don't have days". "Ohh nice" → "What do you need help with?". "Ntg" → "Alright, if you need anything, just let me know."
- **Brochure self-description.** "What kind of AI chatbot are you" got a canned marketing paragraph.
- **Empty music reply.** "I'm sad, play something uplifting" saved a reply that was only the hidden play tag, so no words show.

## What I'll change

1. **Smart AI for real questions.** Casual one-liners (hi, ok, thanks) keep the fast race. For real questions, help requests, follow-ups and long messages, Gemini gets a short head start (about 1.5s). The small AI only answers if Gemini is slow or fails. No extra AI calls, nothing new to pay for.
2. **Full form only when asked for the meaning.** Only "what does MORGAN stand for / full form / meaning". "What are you" gets a short, real answer about what MORGAN does for you.
3. **Natural small talk.** Short, warm, lightly witty replies that match your vibe. Answer "how about you" like a person would, never "I don't have days". Banned openers and closers: "How can I assist you?", "What do you need help with?", "let me know if you need anything".
4. **Real self-description.** "What are you / what kind of AI" gets 1–2 natural sentences, no brochure.
5. **Music replies always have words.** If the reply is only the play tag, add a short line like "Playing *Happy* by Pharrell — this one never misses."

Nothing else changes: same look, Areeba, Companion, slides, search, memory, voice, and the providers you already have.

## How I'll check it

- New tests using your exact chat lines: "What are you", "Fine yours", "Ohh nice", "Ntg", "What kind of AI chatbot are you", "I'm sad, play something uplifting", plus "what does MORGAN stand for" still giving the full form.
- A signed-in live chat in the preview with those lines plus a few real questions, checking which AI answered and how long until the first word.
- Run all existing tests.

## Technical details

- `src/lib/morgan/providers.ts` / the race in `src/routes/api/chat.ts`: add a `preferred` head-start option. When the `intelligence.ts` classifier says the turn isn't casual, non-preferred racers hold their early-valid claim until the grace window passes or the preferred provider errors or aborts. First-valid-wins and save-once stay the same.
- `src/lib/morgan/prompt.ts`: narrow `MORGAN_MEANING_RULE` to explicit meaning/full-form questions. Add a self-description rule and small-talk rules (reciprocal answers, banned generic lines).
- `src/lib/morgan/intelligence.ts`: casual-mode guidance for acknowledgements ("ok", "nice", "ntg", "fine yours").
- `src/components/morgan/chat-session.tsx` / `media-intent.ts`: when visible text is empty after the PLAY tag is removed, add a short confirmation line.
- Update the race rule in `AGENTS.md`.
- Default choices, since the questions were skipped: smart AI for real questions, warm and witty small talk, full form only on request, no battery/device reading.
