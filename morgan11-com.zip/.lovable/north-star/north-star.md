<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

People get help and comfort whenever they need it.

## Metric

People who receive a completed MORGAN reply each day
