<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- The mini bot (code name Areeba) uses bounded deterministic browser-safe rules, a user-chosen name stored in `user_preferences.personality.buddy_name` (sent with each chat request, default "Buddy"), and a separate own-user `areeba_memories` row plus user-scoped local cache; relays return `data-areeba` without calling AI/search or saving MORGAN work memories. Why: lasting private buddy memory and reactions without response lag or a second chat UI.
- Owner responses are resolved by a shared browser-safe rule before cloud search/model calls and local inference. Why: exact, private owner replies with no extra AI cost or latency.
- Image chat races only image-capable provider configurations. Why: text-only racers must not win Lens turns by guessing.
- Lens completion uses a dedicated result event, and Capture finalizes after the recorder stop event with its actual MIME type; closing its panel leaves recording active. Why: unrelated replies and panel navigation must not interrupt captures.
- Text chat streams through `src/routes/api/chat.ts` (AI SDK UI-message stream) and persists to `threads`/`messages`; the route verifies the bearer token itself because server routes bypass serverFn middleware.
- Spoken replies use `src/routes/api/speak.ts` returning a complete WAV; keeps playback simple and reusable for the visualizer meter.
- Live voice runs through the persistent relay in `src/lib/live-relay.server.ts`, dispatched from `src/server.ts` (prod) and `live-vite-plugin.ts` (dev); never replace it with a one-shot SDP endpoint, the call would hang up.
- AI SDK message IDs are stored in `messages.ui_id` (text), never in the UUID primary key.
- The provider race streams progressively: the first provider whose text passes an early validity check claims the win, losers are aborted, and only that provider's deltas reach the client; the answer is still saved once. Why: fast first token without changing first-valid-wins semantics.
- Persona settings (`personalityPrompt`) are appended after identity/security rules in the system prompt. Why: style can never override safety or creator identity.
- MORGAN Capture: browser MediaRecorder enforces the 15-min cap in `src/components/morgan/capture.tsx` (module-level, survives unmount); `src/routes/api/capture.ts` sends audio inline to Gemini for transcript+notes; only text is stored in `capture_notes`. Why: no audio storage, single model call per capture.
- Admin access uses public.user_roles + has_role(); admin pages verify the role server-side in every server fn. Why: no hardcoded credentials, no client-trusted flags.
- Admin telemetry returns only aggregated provider_logs metrics (no user IDs/content). Why: owner visibility without exposing user data; add new metric sources to admin.functions.ts aggregate().
- Adaptive learning: `src/lib/morgan/learning.ts` counts regex signals per message into `learned_profiles` (one row per user, own-row RLS) after the answer streams, and injects a short hint into the prompt from the existing parallel preflight read. Why: personalization with zero extra AI calls or latency; only the admin sees their own profile in /admin, never other users'.
- Deck Engine: `deck-intent.ts` detects a request for a real presentation (and `parseDeckEdit` a follow-up edit, which re-plans the previous `data-deck` from the client history), `deck-engine.ts` plans it as normalized JSON in one provider call (Groq last), and `deck-layout.ts` + `deck-file.ts` compile .pptx/.pdf in the browser through lazy imports; the deck is stored in `messages.parts` as `data-deck`; follow-ups go through `parseDeckFollowUp` (remake = re-plan with a forced new theme + version bump, resend/export/watermark = re-serve the latest deck with no AI call, failed remakes reply honestly and never fall through to the normal answer). Why: one planner call keeps decks fast, and file generation costs nothing until a download is tapped.

- There is no offline AI: without internet the app only shows a "No internet" notice and keeps drafts. Why: the user removed the on-device model.- Automatic long-term memory: `auto-memory.ts` runs a free local filter, then one capped (4s) Groq JSON extraction after the answer text has finished streaming; corrections mark old `memories` rows `status='superseded'` (kept as history) and retrieval reads only active rows with 45-day decay for non-identity memories. Why: lasting personalization without slowing replies or wasting credits.
- Daily digest: the first idle signed-in client each day POSTs `/api/digest`, which claims the `daily_digest` row for the date (PK = single-flight lock) and runs ONE Tavily news search with no AI call and no retry; chat injects the latest digest as untrusted background context. Why: MORGAN "reads the news" daily at near-zero cost and no reply latency.
- Chat setup: the user-message save runs in the background and is awaited only right before an assistant message is stored. Why: writes were adding ~0.5–1 s before the first word.
- Unified response coordination uses a pure bounded classifier before the existing reply race, with optional server-side MORGAN_SOCIAL_PROVIDER=gemini selecting an existing racer and falling back to existing providers; default routing and all configured models stay unchanged. Why: contextual social/emotional/tactical guidance without secondary normal-chat calls.
- Memory categories share the existing text category column and legacy kind mapping; only communication preferences apply globally, while pins boost relevant facts and exact correction targets retain superseded history. Why: preserve existing rows and controls without unrelated personal facts contaminating replies.
- Companion understanding: `companion-intelligence.ts` is a pure rule layer (expectation, message-burst grouping, length) appended to the Companion prompt. Why: better replies with no extra AI call.
